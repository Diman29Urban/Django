from django.apps import AppConfig


class Example2Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'example2'
